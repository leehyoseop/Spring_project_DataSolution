package com.TTValue.main.favplace;

public class Favplace {
	private String f_id;
	private String f_category;
	private String f_place_name;
	
	public Favplace() {
		// TODO Auto-generated constructor stub
	}

	public Favplace(String f_id, String f_category, String f_place_name) {
		super();
		this.f_id = f_id;
		this.f_category = f_category;
		this.f_place_name = f_place_name;
	}

	public String getF_id() {
		return f_id;
	}

	public void setF_id(String f_id) {
		this.f_id = f_id;
	}

	public String getF_category() {
		return f_category;
	}

	public void setF_category(String f_category) {
		this.f_category = f_category;
	}

	public String getF_place_name() {
		return f_place_name;
	}

	public void setF_place_name(String f_place_name) {
		this.f_place_name = f_place_name;
	}
	
}
