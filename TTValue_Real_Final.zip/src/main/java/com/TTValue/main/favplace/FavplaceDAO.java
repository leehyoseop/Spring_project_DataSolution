package com.TTValue.main.favplace;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.TTValue.main.member.Member;

@Service
public class FavplaceDAO {
	@Autowired
	private SqlSession ss;
	//DB에 넣기
	public void addfavplace(HttpServletRequest req) {
		String category = req.getParameter("category");
		String place_name = req.getParameter("place_name");
		Object member = req.getSession().getAttribute("loginMember");
		Member m = (Member) member;
		
		Favplace fp = new Favplace(m.getM_id(), category, place_name);
		
		ss.getMapper(FavplaceMapper.class).addfavplace(fp);
		System.out.println("즐겨찾기 추가 성공");	
	}
	//즐겨찾기페이지에서 가져오기
	public void showfavplace(HttpServletRequest req) {
		Object member = req.getSession().getAttribute("loginMember");
		Member m = (Member) member;
		
		Favplace fp = new Favplace(m.getM_id(), null, null);
		ArrayList<Favplace> fplist = (ArrayList<Favplace>) ss.getMapper(FavplaceMapper.class).showfavplace(fp);
		req.setAttribute("favplace", fplist);
	}
}
