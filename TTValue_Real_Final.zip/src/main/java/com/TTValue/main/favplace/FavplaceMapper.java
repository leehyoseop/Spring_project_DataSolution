package com.TTValue.main.favplace;

import java.util.List;

public interface FavplaceMapper {
	public abstract int addfavplace(Favplace fp);
	
	public abstract List<Favplace> showfavplace(Favplace fp);
}
