package com.TTValue.main.login;

import java.util.List;

import com.TTValue.main.member.Member;

public interface LoginMapper {
	public abstract List<Member> loginfunc();
}
