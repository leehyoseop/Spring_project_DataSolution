package com.TTValue.main.place;

import java.util.List;

public class Places {
	private List<Place> place;
	
	public Places() {
		// TODO Auto-generated constructor stub
	}

	public Places(List<Place> place) {
		super();
		this.place = place;
	}

	public List<Place> getPlace() {
		return place;
	}

	public void setPlace(List<Place> place) {
		this.place = place;
	}
	
}
